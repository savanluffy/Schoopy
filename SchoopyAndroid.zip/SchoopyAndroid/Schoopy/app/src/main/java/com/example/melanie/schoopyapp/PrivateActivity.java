package com.example.melanie.schoopyapp;

import android.annotation.*;
import android.content.*;
import android.database.*;
import android.net.*;
import android.os.*;
import android.provider.*;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.MenuItem;
import android.view.View;
import android.webkit.*;
import android.widget.*;

import com.example.melanie.schoopyapp.Data.*;

import java.io.*;
import java.net.*;
import java.util.ArrayList;

public class PrivateActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, CardView.OnClickListener {
    private static Database db;
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;
    private NavigationView navigationView;
    private ListView privateDocs;
    private CardView Upload;
    final int ACTIVITY_CHOOSE_FILE = 1;
    ArrayAdapter<PrivateFile> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_private);

        try {
            db = Database.newInstance();
            StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
            StrictMode.setVmPolicy(builder.build());
            initComponents();
            setListener();
            this.setTitle(db.getCurLoggedInStudent().getVisitedClass().getRoomDescription());
            fillListWithDocuments();
            privateDocs.setAdapter(arrayAdapter);
            privateDocs.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int pos, long l) {
                    try {
                        PrivateFile selFile = (PrivateFile) adapterView.getItemAtPosition(pos);
                        selFile = db.getPrivateFile(selFile.getFolderRoom().getRoomNr(), Integer.toString(selFile.getFileId()));
                        // Get the directory for the user's public pictures directory.
                        File folder = new File(Environment.getExternalStorageDirectory() + "/myFolder");
                        boolean success = true;
                        if (!folder.exists()) {
                            success = folder.mkdir();
                        }
                        if (success) {

                            //safe file in order to open it later
                            File file = new File(folder.getAbsolutePath() + "/" + selFile.getFileName());
                            FileOutputStream fos = new FileOutputStream(file.getAbsolutePath());
                            fos.write(selFile.getFileContent());
                            fos.close();

                            System.out.println("path:" + file.getAbsolutePath());
                            //launch intent
                            Intent i = new Intent(Intent.ACTION_VIEW);
                            Uri uri = Uri.fromFile(file);
                            String url = uri.toString();
                            //grab mime
                            String newMimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(MimeTypeMap.getFileExtensionFromUrl(url));
                            i.setDataAndType(uri, newMimeType);
                            startActivity(i);
                        } else {
                            throw new Exception("could not open folder");
                        }
                    } catch (Exception ex) {
                        System.out.println("Err:" + ex.getMessage());
                    }

                }

            });

            privateDocs.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int pos, long id) {
                    try {
                        PrivateFile selFile = (PrivateFile) arg0.getItemAtPosition(pos);
                        selFile = db.getPrivateFile(selFile.getFolderRoom().getRoomNr(), Integer.toString(selFile.getFileId()));
                        // Get the directory for the user's public pictures directory.
                        File folder = new File(Environment.getExternalStorageDirectory() + "/myFolder");
                        boolean success = true;
                        if (!folder.exists()) {
                            success = folder.mkdir();
                        }
                        if (success) {
                            //safe file in order to open it later
                            File file = new File(folder.getAbsolutePath() + "/" + selFile.getFileName());
                            FileOutputStream fos = new FileOutputStream(file.getAbsolutePath());
                            fos.write(selFile.getFileContent());
                            fos.close();


                            Intent intentShareFile = new Intent(Intent.ACTION_SEND);

                            if(file.exists()) {
                                String newMimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(MimeTypeMap.getFileExtensionFromUrl(Uri.fromFile(file).toString()));
                                intentShareFile.setType(newMimeType);
                                intentShareFile.putExtra(Intent.EXTRA_STREAM, Uri.parse("file://"+file.getAbsolutePath()));
                                intentShareFile.putExtra(Intent.EXTRA_SUBJECT,
                                        "Sharing File...");
                                intentShareFile.putExtra(Intent.EXTRA_TEXT, "Sharing File...");

                                startActivity(Intent.createChooser(intentShareFile, "Share File"));
                            }

                        } else {
                            throw new Exception("could not open folder");
                        }
                    } catch (Exception ex) {
                        System.out.println("Err:" + ex.getMessage());
                    }
                    return true;
                }
            });

        } catch (Exception ex) {
            Toast.makeText(this, "Error caused by sharing: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void fillListWithDocuments() throws Exception {
        ArrayList<PrivateFile> privateDoc = db.getAllPrivateFiles(Database.getCurLoggedInStudent().getVisitedClass().getRoomNr());
        arrayAdapter = new ArrayAdapter<PrivateFile>(
                this,
                android.R.layout.simple_list_item_1,
                privateDoc);
    }

    private void initComponents() {
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        navigationView = (NavigationView) findViewById(R.id.navigation);
        Upload = findViewById(R.id.btnUpload);
        Upload.setOnClickListener(this);
        privateDocs = findViewById(R.id.listPrivate);
        mToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.open, R.string.close);
        mDrawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void setListener() {
        mDrawerLayout.addDrawerListener(mToggle);
        navigationView.setNavigationItemSelectedListener(this);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mToggle.onOptionsItemSelected(item)) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        try {
            switch (menuItem.getItemId()) {
                case R.id.homepage: {
                    startActivity(new Intent(this, Start.class));
                    break;
                }
                case R.id.logout: {
                    //current user auf null setzen und ausloggen

                    db.setCurLoggedInStudent(null);
                    Intent intent = new Intent(this, LoginActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    break;
                }
                case R.id.myAccount: {
                    startActivity(new Intent(this, MyAccountActivity.class));
                    break;
                }
                case R.id.timetable: {
                    startActivity(new Intent(this, LessonsActivity.class));
                    break;
                }

                case R.id.findTheTeacher: {
                    startActivity(new Intent(this, FindTeacher.class));
                    break;
                }
                case R.id.documents: {
                    startActivity(new Intent(this, DocumentsActivity.class));
                    break;
                }

                default: {
                    Toast.makeText(this, " Nothing selected in the menu!!", Toast.LENGTH_LONG).show();
                    break;
                }
            }

        } catch (Exception ex) {
            Toast.makeText(this, "Error caused by Menu: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }

        return false;
    }

    @Override
    public void onClick(View v) {
        try {
            switch (v.getId()) {
                case R.id.btnUpload: {
                    Intent chooseFile;
                    Intent intent;
                    chooseFile = new Intent(Intent.ACTION_GET_CONTENT);

                    chooseFile.setType("*/*");

                    intent = Intent.createChooser(chooseFile, "Choose a file");
                    startActivityForResult(intent, ACTIVITY_CHOOSE_FILE);

                }
            }
        } catch (Exception ex) {
            Toast.makeText(this, "Error caused by Upload: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {
            switch (requestCode) {
                case ACTIVITY_CHOOSE_FILE: {
                    if (resultCode == RESULT_OK) {
                        Uri uri = data.getData();
                        String filePath = new File(getFilePath(this.getApplicationContext(), uri)).getName();
                        db.addPrivateFile(new PrivateFile(1, filePath, getBytes(getContentResolver().openInputStream(uri)), new LocalDate(12, 12, 1999), null, Database.getCurLoggedInStudent(), Database.getCurLoggedInStudent().getVisitedClass()));
                        //Refresh main activity upon close of dialog box. it is semiprof but notifyDataSetChanged wont work
                        startActivity(new Intent(this, PrivateActivity.class));
                        this.finish();
                    }
                }
            }

        } catch (Exception e) {
            System.out.println("err");
            Toast.makeText(this, "Error caused by Upload: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }

    }

    public byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];

        int len = 0;
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }
        return byteBuffer.toByteArray();
    }

    @SuppressLint("NewApi")
    public static String getFilePath(Context context, Uri uri) throws URISyntaxException {
        String selection = null;
        String[] selectionArgs = null;
        // Uri is different in versions after KITKAT (Android 4.4), we need to
        if (Build.VERSION.SDK_INT >= 19 && DocumentsContract.isDocumentUri(context.getApplicationContext(), uri)) {
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                return Environment.getExternalStorageDirectory() + "/" + split[1];
            } else if (isDownloadsDocument(uri)) {
                final String id = DocumentsContract.getDocumentId(uri);
                uri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));
            } else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];
                if ("image".equals(type)) {
                    uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }
                selection = "_id=?";
                selectionArgs = new String[]{
                        split[1]
                };
            }
        }
        if ("content".equalsIgnoreCase(uri.getScheme())) {


            if (isGooglePhotosUri(uri)) {
                return uri.getLastPathSegment();
            }

            String[] projection = {
                    MediaStore.Images.Media.DATA
            };
            Cursor cursor = null;
            try {
                cursor = context.getContentResolver()
                        .query(uri, projection, selection, selectionArgs, null);
                int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                if (cursor.moveToFirst()) {
                    return cursor.getString(column_index);
                }
            } catch (Exception e) {
            }
        } else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }
        return null;
    }

    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    public static boolean isGooglePhotosUri(Uri uri) {
        return "com.google.android.apps.photos.content".equals(uri.getAuthority());
    }
}
