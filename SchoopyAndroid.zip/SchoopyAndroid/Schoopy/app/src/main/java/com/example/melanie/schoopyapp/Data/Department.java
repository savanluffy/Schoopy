package com.example.melanie.schoopyapp.Data;

public enum Department {
    IT,BUILDINGCONSTRUCTION,CIVILENGINEERING,NETWORKTECHNOLOGY,MEDIATECHNOLOGY, NONE
}
