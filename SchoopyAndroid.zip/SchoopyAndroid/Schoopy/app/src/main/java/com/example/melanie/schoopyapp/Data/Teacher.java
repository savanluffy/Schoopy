package com.example.melanie.schoopyapp.Data;

public class Teacher extends Person{

    public Teacher(String firstName, String lastName, String schoolemail, String username, String password) {
        super(firstName, lastName, schoolemail, username, password);
    }
}
