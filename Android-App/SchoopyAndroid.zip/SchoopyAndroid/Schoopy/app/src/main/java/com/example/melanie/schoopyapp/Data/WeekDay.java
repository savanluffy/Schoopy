package com.example.melanie.schoopyapp.Data;

public enum WeekDay {
    MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY
}
